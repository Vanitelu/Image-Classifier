import os
import numpy as np
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from keras.preprocessing.image import ImageDataGenerator
from keras.utils import to_categorical

# Function to create training and validation data
def create_data(data_dir):
    labels, images = [], []

    for subdir, dirs, files in os.walk(data_dir):
        for file in files:
            if (file.lower().endswith('png') or 
                file.lower().endswith('jpg') or 
                file.lower().endswith('jpeg')):

                label = 0 if 'cat' in subdir else 1
                image = np.array(Image.open(os.path.join(subdir, file)))
                image = np.resize(image, (150, 150, 3))
                image = image / 255.0

                labels.append(label)
                images.append(image)

    images = np.array(images)
    labels = np.array(labels)

    # Splitting data into training and validation sets
    x_train, x_test, y_train, y_test = train_test_split(images, labels, test_size=0.2, random_state=42)

    return x_train, x_test, y_train, y_test

# Load and prepare data
data_dir = 'path_to_your_dataset'
x_train, x_test, y_train, y_test = create_data(data_dir)
y_train = to_categorical(y_train, num_classes=2)
y_test = to_categorical(y_test, num_classes=2)

# Define the model
model = Sequential()
model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(150, 150, 3)))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))
model.add(Flatten())
model.add(Dense(64, activation='relu'))
model.add(Dense(2, activation='softmax'))

# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train the model
history = model.fit(x_train, y_train, batch_size=16, epochs=20, validation_data=(x_test, y_test))

# Evaluate the model
_, accuracy = model.evaluate(x_test, y_test)
print('Test Accuracy: %.2f' % (accuracy*100))